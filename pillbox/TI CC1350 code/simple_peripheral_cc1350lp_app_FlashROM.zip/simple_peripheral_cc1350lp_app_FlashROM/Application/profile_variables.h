/*
 * profile_variables.h
 *
 *  Created on: 9 ����� 2020
 *      Author: Admin
 */

#ifndef APPLICATION_PROFILE_VARIABLES_H_
#define APPLICATION_PROFILE_VARIABLES_H_


extern uint8 currentHour;
extern uint8 currentMinutes;
extern uint8 morningTime;
extern uint8 noonTime;
extern uint8 eveningTime;



#endif /* APPLICATION_PROFILE_VARIABLES_H_ */
